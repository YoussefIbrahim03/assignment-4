//
//  hashtableprobe.h
//  assignment 4
//
//  Created by Youssef Ibrahim on 11/5/22.
//

#ifndef hashtableprobe_h
#define hashtableprobe_h

#include "employee.h"

using namespace std;

class hashprobing
{
private:
    employee* arrayprobe = new employee[9];
    int NOE=0;
    int NOC=0;
    int hashfunction(employee x)
    {
        int key=(x.name.length()+x.age+x.salary+x.experience)%9;
        return key;
    }
public:
    void insert(employee x)
    {
        int i=hashfunction(x);
        int j=i+1;
        if(arrayprobe[i].name=="")
        {
            arrayprobe[i].name=x.name;
            arrayprobe[i].age=x.age;
            arrayprobe[i].salary=x.salary;
            arrayprobe[i].experience=x.experience;
        }
        else
        {
            while(j!=i)
            {
                if(arrayprobe[j].name=="")
                {
                    arrayprobe[j].name=x.name;
                    arrayprobe[j].age=x.age;
                    arrayprobe[j].salary=x.salary;
                    arrayprobe[j].experience=x.experience;
                    break;
                }
                else
                {
                    j=(j+1)%9;
                    NOC++;
                }
                
            }
                if(i==j)
                {
                    cout << "array full" << endl;
                }
        }
        NOE++;
    }
    void remove(employee x)
    {
        int i=hashfunction(x);
        if(arrayprobe[i].name==x.name && arrayprobe[i].age==x.age&& arrayprobe[i].salary==x.salary&& arrayprobe[i].experience==x.experience)
        {
            arrayprobe[i].name="";
            arrayprobe[i].age=0;
            arrayprobe[i].salary=0;
            arrayprobe[i].experience=0;
        }
        else
        {
            int j=i+1;
            while(j!=i)
            {
                if(arrayprobe[j].name==x.name && arrayprobe[j].age==x.age&& arrayprobe[j].salary==x.salary&& arrayprobe[j].experience==x.experience)
                {
                    arrayprobe[j].name="";
                    arrayprobe[j].age=0;
                    arrayprobe[j].salary=0;
                    arrayprobe[j].experience=0;
                    break;
                }
                else
                {
                    j=(j+1)%9;
                }
                
            }
                if(i==j)
                {
                    cout << "employee not found" << endl;
                }
        }
        
    }
    void printlist()
    {
        for(int i=0;i<9;i++)
        {
            if(arrayprobe[i].name!="")
                cout << arrayprobe[i].name << " | " << arrayprobe[i].age << " | " << arrayprobe[i].salary << " | " << arrayprobe[i].experience << "\n";
        }
    }
    int collisionrate()
    {
        return (NOC*100/NOE);
    }
};

#endif /* hashtableprobe_h */
