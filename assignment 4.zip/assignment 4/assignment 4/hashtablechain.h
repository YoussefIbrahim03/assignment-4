//
//  hashtablechain.h
//  assignment 4
//
//  Created by Youssef Ibrahim on 11/5/22.
//

#ifndef hashtablechain_h
#define hashtablechain_h

#include "employee.h"

using namespace std;

class hashchain
{
private:
    employee* arraychain = new employee[9];
    int NOE=0;
    int NOC=0;
    employee* node;
    int hashfunction(employee x)
    {
        int key=(x.name.length()+x.age+x.salary+x.experience)%9;
        return key;
    }
public:
    void insert(employee x)
    {
        int i=hashfunction(x);
        if(arraychain[i].name=="")
        {
            arraychain[i].name=x.name;
            arraychain[i].age=x.age;
            arraychain[i].salary=x.salary;
            arraychain[i].experience=x.experience;
        }
        else
        {
            node=new employee;
            node->name=x.name;
            node->age=x.age;
            node->salary=x.salary;
            node->experience=x.experience;
            NOC++;
            if(arraychain[i].next==NULL)
            {
                arraychain[i].next=node;
            }
            else
            {
                employee* p=arraychain[i].next;
                NOC++;
                while(p->next!=NULL)
                {
                    NOC++;
                    p=p->next;
                }
                p->next=node;
            }
            
        }
        NOE++;
        
    }
    void remove(employee x)
    {
        int i=hashfunction(x);
        employee* p=arraychain[i].next;
        employee *l;
        l=&arraychain[i];
        if(arraychain[i].name==x.name && arraychain[i].age==x.age&& arraychain[i].salary==x.salary&& arraychain[i].experience==x.experience)
        {
            arraychain[i].name="";
            arraychain[i].age=0;
            arraychain[i].salary=0;
            arraychain[i].experience=0;
            if(arraychain[i].next!=NULL)
            {
                while(p!=NULL)
                {
                    l->name=p->name;
                    l->age=p->age;
                    l->salary=p->salary;
                    l->experience=p->experience;
                    l=p;
                    p=p->next;
                }
            }
            
        }
        else
        {
            if(arraychain[i].next!=NULL)
            {
                while(p!=NULL)
                {
                    if(p->name==x.name && p->age==x.age&& p->salary==x.salary&& p->experience==x.experience)
                    {
                        l->next=p->next;
                        delete p;
                    }
                        l=p;
                        p=p->next;
                    
                }
            }
        }
    }
    void printlist()
    {
        for(int i=0;i<9;i++)
        {
            if(arraychain[i].name!="")
            {
                cout << arraychain[i].name << " | " << arraychain[i].age << " | " << arraychain[i].salary << " | " << arraychain[i].experience << "\n";
                if(arraychain[i].next!=NULL)
                {
                    employee* p=arraychain[i].next;
                    while(p!=NULL)
                    {
                        cout << p->name << " | " << p->age << " | " << p->salary << " | " << p->experience << "\n";
                        p=p->next;
                    }
                }
            }
            
        }
    }
    int collisionrate()
    {
        return (NOC*100/NOE);
    }
};


#endif /* hashtablechain_h */
