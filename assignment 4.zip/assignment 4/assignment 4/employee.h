//
//  employee.h
//  assignment 4
//
//  Created by Youssef Ibrahim on 11/5/22.
//

#ifndef employee_h
#define employee_h

#include <string>

using namespace std;

class employee
{
public:
    string name="";
    int age=NULL, salary=NULL, experience=NULL;
    employee* next=NULL;
    void employeecons(string empname, int agenum, int salarynum, int experienceyears)
    {
        name=empname;
        age=agenum;
        salary=salarynum;
        experience=experienceyears;
    }
};

#endif /* employee_h */
