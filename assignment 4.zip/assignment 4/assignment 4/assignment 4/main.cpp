//
//  main.cpp
//  assignment 4
//
//  Created by Youssef Ibrahim on 11/5/22.
//

#include <iostream>
#include <queue>
#include <string>
#include "employee.h"
#include "hashtableprobe.h"
#include "hashtablechain.h"

using namespace std;


int main()
{
    hashchain hashchain1;
    hashprobing hashprobe1;
    employee e1,e2,e3,e4,e5,e6,e7,e8,e9;
    e1.employeecons( "mina", 30 ,10000 ,4);
    e2.employeecons( "fawzy", 45 ,4000 ,8);
    e3.employeecons( "yara", 19 ,2000 ,0);
    e4.employeecons( "mariam", 32 ,8000 ,2);
    e5.employeecons( "ayman", 33 ,4000 ,8);
    e6.employeecons( "roshdy", 28 ,9000 ,3);
    e7.employeecons( "aya", 26 ,6000 ,3);
    e8.employeecons( "abdallah", 29 ,7000 ,4);
    e9.employeecons( "fatma", 21 ,3000 ,1);
    cout << "chaining table\n";
    hashchain1.insert(e1);
    hashchain1.insert(e2);
    hashchain1.insert(e3);
    hashchain1.insert(e4);
    hashchain1.insert(e5);
    hashchain1.insert(e6);
    hashchain1.insert(e7);
    hashchain1.insert(e8);
    hashchain1.insert(e9);
    hashchain1.printlist();
    cout << hashchain1.collisionrate() << "% collision rate\n";
    hashchain1.remove(e5);
    cout << endl << "ayman removed\n";
    hashchain1.printlist();
    cout << endl << endl << endl << endl << "linear probing table\n";
    hashprobe1.insert(e1);
    hashprobe1.insert(e2);
    hashprobe1.insert(e3);
    hashprobe1.insert(e4);
    hashprobe1.insert(e5);
    hashprobe1.insert(e6);
    hashprobe1.insert(e7);
    hashprobe1.insert(e8);
    hashprobe1.insert(e9);
    hashprobe1.printlist();
    cout << hashprobe1.collisionrate() << "% collision rate\n";
    hashprobe1.remove(e5);
    cout << endl << "ayman removed\n";
    hashprobe1.printlist();
    
    return 0;
}
